int pop(void);
void push(int i);
int is_full(void);
int is_empty(void);
void make_empty(void);
void stack_overflow(void);